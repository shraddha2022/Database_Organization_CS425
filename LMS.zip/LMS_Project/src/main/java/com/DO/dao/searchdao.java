package com.DO.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DO.model.book;
import com.DO.model.search;

public class searchdao {
	final String url = "jdbc:postgresql://0.0.0.0:5432/LMS";
	final String user = "postgres";
	final String password = "0256";//"<add your password>";

	public search getsearch(String documentID) {
		
		   
	
        String mySQL = "SELECT DocumentID, title "
        		+ "FROM Documents "
        		+ "WHERE DocumentID = ?";
		
		
		search ob1 = new search();

		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try (Connection conn = DriverManager.getConnection(url, user, password);
	 		    PreparedStatement pStmt = conn.prepareStatement(mySQL)){
	 			
	 		pStmt.setString(1, documentID.trim());
	 		
            ResultSet rs = pStmt.executeQuery();
            
            while (rs.next()) {
            	/* Retrieves the value of the designated column in the current row 
            	   of this ResultSet object as a String in the Java programming language.
            	*/
            	ob1.setDocumentID(rs.getString("documentID"));
            	ob1.setTitle(rs.getString("title"));
            	
            }
       }catch (SQLException e) {
    		 System.out.println(e.getMessage());
       }
		
		return ob1;
}
}
