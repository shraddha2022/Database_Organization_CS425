package com.DO.dao;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.*;

import com.DO.model.check;

public class checkdao {
	 final String url = "jdbc:postgresql://0.0.0.0:5432/LMS";
		final String user = "postgres";
		final String password = "0256";//"<add your password>";

		public ArrayList<check> getcheck() {
			
			   
		
	        String mySQL = "SELECT UserID,DocumentID, title,borrow_date,return_date "
	        		+ "FROM Documents "
	        		+ "WHERE status= False";
			
			//List <check> l1=new ArrayList<check>();
			ArrayList<check> x = new ArrayList<check>();
			
          
			try {
				Class.forName("org.postgresql.Driver");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try (Connection conn = DriverManager.getConnection(url, user, password);
		 		    PreparedStatement pStmt = conn.prepareStatement(mySQL)){
		 			
		 		//pStmt.setString(1, documentID.trim());
		 		
	            ResultSet rs = pStmt.executeQuery();
	         
	           while (rs.next()) {
	            	/* Retrieves the value of the designated column in the current row 
	            	   of this ResultSet object as a String in the Java programming language.
	            	*/
	        	   check ob1 = new check();
	                ob1.setUserID(rs.getString("UserID"));
	            	ob1.setDocumentID(rs.getString("documentID"));
	            	ob1.setTitle(rs.getString("title"));
	            	ob1.setBorrow_date(rs.getString("borrow_date"));
                    ob1.setReturn_date(rs.getString("return_date"));
                  //  ob1.setStatus(rs.getString("status"));
	            	x.add(ob1);
	           }
	       }catch (SQLException e) {
	    		 System.out.println(e.getMessage());
	       }
			
			return x;
		

}}
