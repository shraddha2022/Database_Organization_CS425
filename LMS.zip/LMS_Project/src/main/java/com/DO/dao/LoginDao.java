package com.DO.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DO.model.login;

public class LoginDao {
	
	
	final String url = "jdbc:postgresql://0.0.0.0:5432/LMS";
	final String user = "postgres";
	final String password = "0256"; //"<add your password>";
	
	
			private String dbDriver = "org.postgresql.Driver";
				
				public void loadDriver(String dbDriver)
				{
					try {
						Class.forName(dbDriver);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				public Connection getConnection()
				{
					Connection con = null;
					try {
						con = DriverManager.getConnection(url, user, password);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return con;
				}
				
	public String authenticateUser(login loginBean)
	{
	   // String userName = loginBean.getUserId();
	  //  String password = loginBean.getPassword();
	 
	   loadDriver(dbDriver);
	 //   Statement pstmt = null;
	 //   ResultSet rs = null;
	 
	    String userNameDB = "";
	    String passwordDB = "";
	    String roleDB = "";
	    String mySQL = "SELECT * FROM Users where UserId= ? and password=? ";
	 
	   try (Connection conn = DriverManager.getConnection(url, user, password);
		 		    PreparedStatement pStmt = conn.prepareStatement(mySQL)){
		 			
		 		pStmt.setString(1, loginBean.getUserId());
		 		pStmt.setString(2, loginBean.getPassword());
		 		
	            ResultSet rs = pStmt.executeQuery();
	            
	 
	        while(rs.next())
	        {
	            userNameDB = rs.getString("UserId").trim();
	            passwordDB = rs.getString("password").trim();
	            roleDB = rs.getString("role").trim();
	 
	            if(loginBean.getUserId().equals(userNameDB) && loginBean.getPassword().equals(passwordDB) &&  roleDB.equals("Librarian"))
	            {
	            return "Admin_Role";
	            }
	           else if(loginBean.getUserId().equals(userNameDB) && loginBean.getPassword().equals(passwordDB) &&  roleDB.equals("Member"))
	           {
	            return "User_Role";
	        }}}
	      
	        catch(SQLException e)
	    {
	        e.printStackTrace();
	    }
	    return "Invalid user credentials";

}
}

