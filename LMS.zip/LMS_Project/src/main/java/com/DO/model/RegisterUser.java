package com.DO.model;

public class RegisterUser {

	private String UserID;
	private String Name;
	private String Joingdate;
	private String password;
	private String role;
	private String zipcode;
	private String city;
	
	public RegisterUser()
	{
		super();
	}
	public RegisterUser(String UserID,String Name, String Joingdate,String password,String role,String zipcode,String city){
		super();
		this.UserID=UserID;
		this.Name=Name;
		this.Joingdate=Joingdate;
		this.password=password;
		this.role=role;
		this.zipcode=zipcode;
		this.city=city;
	}
	@Override
	public String toString() {
		return "RegisterUser [UserID=" + UserID + ", Name=" + Name + ", Joingdate=" + Joingdate + ", password="
				+ password + ", role=" + role + ", zipcode=" + zipcode + ", city=" + city + "]";
	}
	public String getUserID() {
		return UserID.trim();
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getJoingdate() {
		return Joingdate;
	}
	public void setJoingdate(String joingdate) {
		Joingdate = joingdate;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
